//
//  Keychain.swift
//  media
//
//  Created by миша on 05.07.2022.
//

import Foundation
import KeychainSwift

final class KeychainHelper {
    
    static let standard = KeychainHelper()
    private init() {}
}

func save(_ data: Data, service: String, account: String) {
    
    let query = [
        kSecValueData: data,
        kSecClass: kSecClassGenericPassword,
        kSecAttrService: service,
        kSecAttrAccount: account,
    ] as CFDictionary
    let status = SecItemAdd(query, nil)
    if status != errSecSuccess {
        print("Error: \(status)")
    }
    let keychain = KeychainSwift()
    keychain.set("access-token", forKey: "my key")
    if let myValue = keychain.get("my key") {
        print(myValue)
    }
}
