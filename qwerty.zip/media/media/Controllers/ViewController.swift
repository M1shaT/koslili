import UIKit
import WebKit
import Foundation
import KeychainSwift

class ViewController: UIViewController{

    // открывает ТабБар после аавторизации
    func openTabBar(){
        navigationController?.viewControllers = [/*массив стори*/]
    }
    
    let webView = WKWebView()
    override func viewDidLoad(){
        super.viewDidLoad()
        view.addSubview(webView)
        webView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        webView.navigationDelegate = self
        // загрузка
        loadRequest()
    }
        
    private func loadRequest(){
        guard let urlAuth = URL(string: "https://unsplash.com/oauth/authorize?client_id=FvR9B5V76FtD4aPtStXGJFP9FCOgbZ3WhYLlYNyZsy4&redirect_uri=urn:ietf:wg:oauth:2.0:oob&response_type=code&scope=public") else { return }
        webView.load(URLRequest(url: urlAuth))
    }
}

//выводит логи в консоль + пост ркст/джсон
extension ViewController: WKNavigationDelegate{
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!){
        print(webView.url?.absoluteString as Any)
        if let code = webView.url?.getParameters("code"){
            print(code)
            let json: [String: Any] = ["title": "ABC",
                                       "dict": ["1":"First", "2":"Second"]]
            let jsonData = try? JSONSerialization.data(withJSONObject: json)
            let url = URL(string: "https://unsplash.com/oauth/token?client_id=FvR9B5V76FtD4aPtStXGJFP9FCOgbZ3WhYLlYNyZsy4&client_secret=_TMdHEWL7PoICXJq_atPn-g_w1ziEBIygnb82SNJtoQ&redirect_uri=urn:ietf:wg:oauth:2.0:oob&code=\(code)&grant_type=authorization_code")!
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.httpBody = jsonData
            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                guard let data = data, error == nil else {
                    print(error?.localizedDescription ?? "No data")
                    return
                }
                let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
                if let responseJSON = responseJSON as? [String: Any] {
                    print(responseJSON)
                }
            }
            task.resume()
            }
        }
    }
    
//расширение деления урлы на компоненты
 extension URL {
     func getParameters(_ queryParam: String) -> String? {
         guard let url = URLComponents(string: self.absoluteString) else { return nil }
         if let parameters = url.queryItems {
             return parameters.first(where: { $0.name == queryParam })?.value
         } else if let paramPairs = url.fragment?.components(separatedBy: "?").last?.components(separatedBy: "&") {
             for pair in paramPairs where pair.contains(queryParam) {
                 return pair.components(separatedBy: "=").last
             }
             return nil
         } else {
             return nil
         }
     }
 }
